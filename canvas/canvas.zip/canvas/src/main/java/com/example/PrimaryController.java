package com.example;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;

public class PrimaryController implements Initializable {

  @FXML
  private Canvas canvas;

  private GraphicsContext gc;

  @FXML
  private RadioButton seno;

  @FXML
  private RadioButton coseno;

  @FXML
  private ToggleGroup group;

  @FXML
  void setSeno(ActionEvent event) {
    gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    gc.setFill(Color.BLACK);
    gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    gc.setFill(Color.WHITE);
    for (double i = 0; i < canvas.getWidth(); i += 0.1) {
      gc.fillRect(i * 40, (canvas.getHeight() / 2 + Math.sin(i) * (-40)), 1, 1);
    }
  }

  @FXML
  void setCoseno(ActionEvent event) {
    gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    gc.setFill(Color.BLACK);
    gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    gc.setFill(Color.WHITE);
    for (double i = 0; i < canvas.getWidth(); i += 0.1) {
      gc.fillRect(i * 40, (canvas.getHeight() / 2 - Math.cos(i) * 40), 1, 1);
    }
  }

  @FXML
  public void initialize(URL location, ResourceBundle resources) {
    gc = canvas.getGraphicsContext2D();
    gc.setFill(Color.BLACK);
    gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
    gc.setFill(Color.WHITE);
  }
}
